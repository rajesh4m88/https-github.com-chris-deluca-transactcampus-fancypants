DECLARE
  output_var VARCHAR2(50);
  LOW        INTEGER;
  HIGH       INTEGER;
  a_var      INTEGER;
  b_var      INTEGER;
BEGIN
  LOW   := &LOW;
  HIGH  := &HIGH;
  a_var := &a;
  b_var := &b;
  FOR i IN LOW..HIGH
  LOOP
    SELECT
      CASE
        WHEN remainder(i,a_var) = 0
        AND remainder(i,b_var)  = 0
        THEN 'FancyPants'
        WHEN remainder(i,a_var) = 0
        THEN 'Fancy'
        WHEN remainder(i,b_var) = 0
        THEN 'Pants'
      END AS out_1
    INTO
      output_var
    FROM
      dual;
    DBMS_OUTPUT.PUT_LINE (i || ' = ' || output_var);
  END LOOP;
END;
/